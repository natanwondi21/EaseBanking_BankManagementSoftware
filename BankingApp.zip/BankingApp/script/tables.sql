CREATE TABLE customers
(
  customer_id integer NOT NULL AUTO_INCREMENT,
  acc_no character varying(50),
  cname character varying(50),
  dob character varying(50),
  acc_type character varying(50),
  gender character varying(50),
  mob character varying(50),
  address character varying(50),
  pin character varying(6),
  micr_no character varying(50),
  security_question character varying(200),
  s_answer character varying(200),
  nationality character varying(50),
  caste character varying(50),
  avl_balance integer,
  CONSTRAINT CUS_PK PRIMARY KEY(customer_id)
  );
  
  
  
  CREATE TABLE transactions
(
  transaction_id integer NOT NULL AUTO_INCREMENT,
  account_number character varying(50),
  customer_name character varying(50),
  balance integer,
  CONSTRAINT TRAN_PK PRIMARY KEY(transaction_id)
)