/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bankingapp.dao;

import bankingapp.db.JdbcConnectionApp;
import bankingapp.model.Customer;
import bankingapp.model.Transaction;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 1613985
 */
public class CustomerDao {
    
     public  static List<String>  getCustomerAccountNum() {
        try {
            List<String> lst=new ArrayList<String>();
            String sql = "SELECT * FROM customers";
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
            ResultSet RS;
            RS = statement.executeQuery();
            while(RS.next())
            {
                lst.add(RS.getString("acc_no"));
            }
            return lst;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
     public static ResultSet showAllCustomers() {
        try {
            String sql = "SELECT * FROM customers";
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
            ResultSet RS;

            RS = statement.executeQuery();
            return RS;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
     
      public static boolean checkCustomerExist(String accNo, String pin) {

        String sql = "SELECT * FROM customers WHERE Acc_No = ? and Pin = ?";
        try {
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
            statement.setString(1, accNo);
            statement.setString(2, pin);

            ResultSet result = statement.executeQuery();

            if (result.next()) {
                return true;
            } else {
                return false;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
      
       public static ResultSet showAllCustomerByname(String customerName) {
        try {
            String sql = "SELECT * FROM customers where Acc_No=?";
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
            ResultSet RS;

            statement.setString(1,customerName);
            RS = statement.executeQuery();
            return RS;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
       
        public static ResultSet showAllCustomerByAccountNumber(String accNum) {
        try {
            String sql = "SELECT * FROM customers where acc_no=?";
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
            ResultSet RS;

            statement.setString(1,accNum);
            RS = statement.executeQuery();
            return RS;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
       
            public static boolean updateCustomerRecords(Customer customerA) {

 
        String sql = "update customers set acc_no =?,dob=?,acc_type=?,gender=?,mob=?,address=?,security_question=?,"
                + "nationality=?,caste=?"
                + "where acc_no = ?";
        try {
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
              
            statement.setString(1, customerA.getAccNo());
             statement.setString(2, customerA.getDob());
            statement.setString(3, customerA.getAccType());
             statement.setString(4, customerA.getGender());
            statement.setString(5, customerA.getMob());
             statement.setString(6, customerA.getAddresss());
             statement.setString(7, customerA.getSecurityQues());
              statement.setString(8, customerA.getNationality());
               statement.setString(9, customerA.getCaste());
statement.setString(10, customerA.getAccNo());
            int rowAffected = statement.executeUpdate();
           return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
            
               public static boolean deleteCustomer(String cName) {

 
        String sql = "delete from  customers where acc_no = ?";
        try {
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
              
            statement.setString(1, cName);
            int rowAffected = statement.executeUpdate();
           return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
            
             public static boolean updateCustomerDepositRecords(int balance,String cName) {

 
        String sql = "update customers set avl_balance =? where acc_no = ?";
        try {
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
              
            statement.setInt(1, balance);
             statement.setString(2, cName);
           
            int rowAffected = statement.executeUpdate();
           return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
           public static boolean updateCustomerDepositRecordsByAccountNumber(int balance,String accNo) {

 
        String sql = "update customers set avl_balance =? where acc_no = ?";
        try {
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
              
            statement.setInt(1, balance);
             statement.setString(2, accNo);
           
            int rowAffected = statement.executeUpdate();
           return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
          
             public static boolean changePin(String cName,String oldPin,String newPin) {

 
        String sql = "update customers set pin =? where acc_no = ? and pin=?";
        try {
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
              
            statement.setString(1, newPin);
             statement.setString(2, cName);
             statement.setString(3, oldPin);
            int rowAffected = statement.executeUpdate();
           return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
             
             public static boolean addNewCustomer(Customer veh)
    {
        
      
         String sql = "insert into customers(acc_no, cname, dob, acc_type, gender, mob, address, pin, micr_no, security_question, s_answer, nationality, caste, avl_balance) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
            statement.setString(1, veh.getAccNo());
             statement.setString(2, veh.getcName());
             statement.setString(3, veh.getDob());
             statement.setString(4, veh.getAccType());
             statement.setString(5, veh.getGender());
             statement.setString(6, veh.getMob());
             statement.setString(7, veh.getAddresss());
             statement.setString(8, veh.getPin());
             statement.setString(9, veh.getMicrNo());
             statement.setString(10, veh.getSecurityQues());
             statement.setString(11, veh.getSecurityAns());
             statement.setString(12, veh.getNationality());
             statement.setString(13, veh.getCaste());
              statement.setInt(14, veh.getBalance());
           
     
            int rowAffected = statement.executeUpdate();
            System.out.println("Transaction Added..");
           return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
