/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bankingapp.dao;

import bankingapp.db.JdbcConnectionApp;
import bankingapp.model.Transaction;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author 1613985
 */
public class TransactionDao {
      public static ResultSet showAllTransactions() {
        try {
            String sql = "SELECT * FROM transactions";
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
            ResultSet RS;

            RS = statement.executeQuery();
            return RS;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
      
      public static boolean addNewTransaction(Transaction veh)
    {
         String sql = "insert into transactions(account_number, customer_name, balance) values(?,?,?)";
        try {
            PreparedStatement statement = JdbcConnectionApp.getConnectionDb().prepareStatement(sql);
            statement.setString(1, veh.getAccNo());
             statement.setString(2, veh.getName());
            statement.setInt(3, veh.getBalance());
     
            int rowAffected = statement.executeUpdate();
            System.out.println("Transaction Added..");
           return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
